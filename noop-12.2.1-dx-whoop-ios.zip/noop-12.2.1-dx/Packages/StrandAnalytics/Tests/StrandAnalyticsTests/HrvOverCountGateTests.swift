import XCTest
import WhoopProtocol
@testable import StrandAnalytics

/// #1118: RMSSD is withheld on a night whose own R-R banks more beat-time than the wall clock it spans.
///
/// Each over-count case asserts TWICE: that the gated call returns nil, AND that the very same beats do
/// produce an RMSSD through `sessionHrvWindows`. Without that second assertion the test would pass just as
/// well against a window that had no usable beats at all, proving nothing about the gate.
/// Byte-parity twin of Kotlin `HrvOverCountGateTest`.
final class HrvOverCountGateTests: XCTestCase {

    private func windowsYieldRMSSD(_ start: Int, _ end: Int, _ rr: [RRInterval]) -> Bool {
        !SleepStager.sessionHrvWindows(start: start, end: end, rr: rr, stages: []).compactMap { $0.rmssd }.isEmpty
    }

    /// Two near-equal beats per second: the shape a same-second collapse WOULD bring back under the
    /// ceiling. It must still be withheld, and this is the case that guards the gate's cheap
    /// classification — `sessionAvgHRV` passes coverage as its own collapsed figure to avoid a sort, so a
    /// night of this shape reports `crossSecondOverCount` internally. The outcome is what matters and is
    /// asserted here; restoring the real collapsed figure would relabel this night and change nothing.
    func testSameSecondOverCountIsWithheld() {
        let start = 1_000, end = 1_600
        var rr: [RRInterval] = []
        for i in 0..<600 {
            rr.append(RRInterval(ts: start + i, rrMs: 900, transport: .whoopHistorical))
            rr.append(RRInterval(ts: start + i, rrMs: 905, transport: .whoopHistorical))
        }
        XCTAssertTrue(windowsYieldRMSSD(start, end, rr), "precondition: these beats DO yield an RMSSD")
        XCTAssertNil(SleepStager.sessionAvgHRV(start: start, end: end, rr: rr),
                     "an over-counted night must report no HRV")
    }

    /// Two beats per second far enough apart that a same-second collapse cannot reach them.
    func testCrossSecondOverCountIsWithheld() {
        let start = 1_000, end = 1_600
        var rr: [RRInterval] = []
        for i in 0..<600 {
            rr.append(RRInterval(ts: start + i, rrMs: 880, transport: .whoopHistorical))
            rr.append(RRInterval(ts: start + i, rrMs: 960, transport: .whoopHistorical))
        }
        XCTAssertTrue(windowsYieldRMSSD(start, end, rr), "precondition: these beats DO yield an RMSSD")
        XCTAssertNil(SleepStager.sessionAvgHRV(start: start, end: end, rr: rr),
                     "an over-counted night must report no HRV")
    }

    /// The gate must not touch an ordinary night: one beat per second, coverage ~1.0.
    func testAPlausibleNightStillReportsItsHRV() {
        let start = 1_000, end = 1_600
        let rr = (0..<600).map { RRInterval(ts: start + $0, rrMs: $0 % 2 == 0 ? 980 : 1_020) }
        let hrv = SleepStager.sessionAvgHRV(start: start, end: end, rr: rr)
        XCTAssertNotNil(hrv, "a plausible night must keep its HRV")
        XCTAssertGreaterThan(hrv ?? 0, 0, "and it must be a real reading, not zero")
    }

    /// A sparse night is underCovered, which is honest data and stays trusted.
    func testAnUnderCoveredNightIsNotGated() {
        let start = 1_000, end = 1_600
        let rr = (0..<300).map { RRInterval(ts: start + $0 * 2, rrMs: $0 % 2 == 0 ? 980 : 1_020) }
        XCTAssertNotNil(SleepStager.sessionAvgHRV(start: start, end: end, rr: rr),
                        "sparse is not the same as over-counted")
    }

    /// A pre-v58 database cannot identify which transport should win. Those nights keep the value users
    /// had before recipe v3, while the existing over-count series exposes the value as unverified.
    func testLegacyOverCountKeepsItsUnverifiedHRV() {
        let start = 1_000, end = 1_600
        var rr: [RRInterval] = []
        for i in 0..<600 {
            rr.append(RRInterval(ts: start + i, rrMs: 880))
            rr.append(RRInterval(ts: start + i, rrMs: 960))
        }
        XCTAssertNotNil(SleepStager.sessionAvgHRV(start: start, end: end, rr: rr))
    }

    /// The verdict mapping itself, so the seam above and the rule stay pinned separately.
    func testOnlyTheTwoOverCountVerdictsRefuse() {
        XCTAssertFalse(HRVAnalyzer.successiveDiffIsTrustworthy(.sameSecondOverCount))
        XCTAssertFalse(HRVAnalyzer.successiveDiffIsTrustworthy(.crossSecondOverCount))
        XCTAssertTrue(HRVAnalyzer.successiveDiffIsTrustworthy(.plausible))
        XCTAssertTrue(HRVAnalyzer.successiveDiffIsTrustworthy(.underCovered))
        XCTAssertTrue(HRVAnalyzer.successiveDiffIsTrustworthy(.unmeasurable))
    }

    /// It refuses exactly what the SDNN gate refuses: same rule, stated twice on purpose, never drifting.
    func testItRefusesTheSameVerdictsAsTheSdnnGate() {
        let all: [HRVAnalyzer.RrCoverageVerdict] =
            [.plausible, .underCovered, .sameSecondOverCount, .crossSecondOverCount, .unmeasurable]
        for v in all {
            XCTAssertEqual(HRVAnalyzer.beatSpreadIsTrustworthy(v),
                           HRVAnalyzer.successiveDiffIsTrustworthy(v),
                           "verdict \(v) must be judged alike by both gates")
        }
    }

    /// #2128: the verdict the nightly trace prints must be the one the value gate actually acted on.
    ///
    /// Asserted as an AGREEMENT rather than against a fixed label, so the trace deriving its reason from
    /// existing calls cannot let the explanation and the decision drift apart. A bare `reported=nil`
    /// beside real window means reads as a value that went missing; it is usually this gate refusing an
    /// over-counted night on purpose, and the trace can only say so if it asks the same helper.
    func testTheTracedVerdictAgreesWithTheGate() {
        let start = 1_000, end = 1_600
        var overCounted: [RRInterval] = []
        var plausible: [RRInterval] = []
        // Transport-tagged: this fork keeps a wholly LEGACY over-counted night's HRV (see
        // `testLegacyOverCountKeepsItsUnverifiedHRV`), so the gate only refuses once provenance exists.
        for i in 0..<600 {
            overCounted.append(RRInterval(ts: start + i, rrMs: 880, transport: .whoopHistorical))
            overCounted.append(RRInterval(ts: start + i, rrMs: 960, transport: .whoopHistorical))
            plausible.append(RRInterval(ts: start + i, rrMs: 900))
        }
        for beats in [overCounted, plausible] {
            XCTAssertTrue(windowsYieldRMSSD(start, end, beats), "precondition: these beats DO yield an RMSSD")
            // The trace derives "the gate refused" from exactly this pair, so pin the pair rather than
            // a label: windows that DID yield an RMSSD, beside a nil value, can only be the gate.
            let cov = HRVAnalyzer.rrCoverage(tsSec: beats.map { $0.ts }, rrMs: beats.map { Double($0.rrMs) })
            let verdict = HRVAnalyzer.classifyCoverage(coverage: cov, collapsed: cov)
            XCTAssertEqual(SleepStager.sessionAvgHRV(start: start, end: end, rr: beats) == nil,
                           !HRVAnalyzer.successiveDiffIsTrustworthy(verdict),
                           "a withheld night must be exactly the night whose own beats were refused")
        }
    }
}

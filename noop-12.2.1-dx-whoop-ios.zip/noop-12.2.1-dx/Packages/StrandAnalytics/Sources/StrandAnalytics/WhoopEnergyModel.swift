import Foundation

/// Evidence behind a WHOOP energy bucket. Keeping this explicit prevents inferred movement or a
/// basal fill from being presented as directly measured energy.
public enum EnergyEvidence: String, Codable, Equatable, Sendable {
    case observed
    case inferred
    /// Heart rate was observed, but the energy above basal is a deliberately bounded physiological
    /// estimate rather than evidence of activity.
    case physiological
    case modeled
}

/// The context selected before any calorie equation runs. Heart rate is an intensity input inside a
/// context; it is never, by itself, proof that the wearer was active.
public enum EnergyContext: String, Codable, CaseIterable, Equatable, Sendable {
    case offWrist
    case sleep
    case confirmedWorkout
    case locomotion
    case sedentary
    case unresolvedElevatedHR
    case unknown
}

public enum EnergyWorkoutKind: String, Codable, Equatable, Sendable {
    case endurance
    case resistance
    case other

    /// The share of the heart-rate reserve that shows up as oxygen-uptake reserve for this kind.
    ///
    /// Endurance work is where the ACSM relationship (%HRR ≈ %VO2R, Swain & Leutholtz 1997) was
    /// established, so it takes it whole. Lifting does not follow it: the pressor response to a heavy
    /// set drives heart rate far ahead of oxygen uptake — circuit weight training ran at ~70–80 % of
    /// HRmax while VO2 sat at ~40–50 % of VO2max (Hurley et al. 1984) — which on the reserve scales is
    /// about 0.6. `other` (HIIT, team sports, an unnamed "Workout") sits between the two.
    public var vo2ReserveShare: Double {
        switch self {
        case .endurance: return 1.0
        case .other: return 0.8
        case .resistance: return 0.6
        }
    }

    /// The curve a logged session is priced on, from its sport label.
    ///
    /// Matched on letters only, lower-cased, so every spelling the importers write resolves alike:
    /// the native logger's "Strength Training", WHOOP's camel-cased "TraditionalStrengthTraining",
    /// Apple's "HKWorkoutActivityTypeTraditionalStrengthTraining", "Treadmill walk". Resistance is
    /// tested first, so "Functional strength training" is a lift rather than an endurance session.
    public static func forSport(_ sport: String) -> EnergyWorkoutKind {
        let key = sport.lowercased().filter { $0.isLetter }
        if ["strength", "weight", "lifting", "crossfit", "functional", "yoga", "pilates"]
            .contains(where: key.contains) { return .resistance }
        // "hiking" is listed on its own: it does not contain "hike", and a hike was priced as `other`.
        if ["run", "walk", "cycle", "cycling", "bike", "swim", "row", "hike", "hiking", "ski",
            "elliptical", "stair", "ruck"]
            .contains(where: key.contains) { return .endurance }
        return .other
    }

    /// Whether a session's sport moves the body on foot, so its cost follows from speed.
    ///
    /// Walking, running, hiking and rucking are priced by the pace the strap and phone measured, the way
    /// ordinary walking outside a session already is. Stairs, cycling, rowing, swimming and the elliptical
    /// are left to heart rate: the speed table has no column for climbing, and their movement signal is
    /// not ground speed.
    public static func isOnFoot(sport: String) -> Bool {
        let key = sport.lowercased().filter { $0.isLetter }
        if ["stair", "elliptical", "cycle", "cycling", "bike", "swim", "row"]
            .contains(where: key.contains) { return false }
        return ["walk", "run", "hike", "hiking", "ruck", "treadmill", "jog"].contains(where: key.contains)
    }
}

/// One fixed-width WHOOP energy input window. Callers normally use five-minute buckets; duration is
/// retained so DST boundaries and clipped first/last buckets remain exact.
public struct WhoopEnergyBucket: Equatable, Sendable {
    public let start: Int
    public let durationSeconds: Int
    /// Seconds inside the wall-clock bucket backed by HR. Movement can cover the full bucket even when
    /// optical samples are sparse; keeping these durations separate prevents cadence inflation.
    public let hrCoverageSeconds: Int
    public let averageHR: Double?
    public let motionIntensity: Double?
    public let steps: Int?
    public let distanceM: Double?
    public let strideM: Double?
    /// The strap's OWN `activity_class@63` code — 0 still / 1 walk / 2 run. A direct classification
    /// rather than something inferred from cadence, so it sets a floor the weaker signals cannot pull
    /// below. WHOOP 5/MG only: a 4.0 record carries no such field and leaves this nil.
    public let activityClass: Int?
    /// Seconds in this bucket for which movement was independently observed. A few steps near a
    /// five-minute boundary must not turn the entire bucket into five minutes of walking.
    public let movementSeconds: Int
    /// True when a dense movement stream covered this window. This distinguishes a real still reading
    /// (`activityClass == 0`, no counter delta) from a WHOOP 4 / data-gap bucket with no motion evidence.
    public let hasMovementCoverage: Bool
    public let isWorkout: Bool
    public let workoutKind: EnergyWorkoutKind
    /// The session is walking, running, hiking or rucking (`EnergyWorkoutKind.isOnFoot`), so a bucket
    /// with movement evidence is priced by pace rather than by heart rate.
    public let workoutOnFoot: Bool
    /// The Compendium MET for the session's sport (`ActivityMETCatalog`), the price of a workout bucket
    /// when no aerobic ceiling is known yet.
    public let workoutTableMET: Double?
    public let isSleep: Bool
    public let isOffWrist: Bool

    public init(start: Int, durationSeconds: Int = 300, hrCoverageSeconds: Int? = nil,
                averageHR: Double? = nil,
                motionIntensity: Double? = nil, steps: Int? = nil, distanceM: Double? = nil,
                strideM: Double? = nil, activityClass: Int? = nil, isWorkout: Bool = false,
                workoutKind: EnergyWorkoutKind = .other, workoutOnFoot: Bool = false,
                workoutTableMET: Double? = nil, isSleep: Bool = false,
                isOffWrist: Bool = false, hasMovementCoverage: Bool = false,
                movementSeconds: Int? = nil) {
        self.start = start
        self.durationSeconds = durationSeconds
        self.hrCoverageSeconds = min(durationSeconds, max(0, hrCoverageSeconds
            ?? (averageHR == nil ? 0 : durationSeconds)))
        self.averageHR = averageHR
        self.motionIntensity = motionIntensity
        self.steps = steps
        self.distanceM = distanceM
        self.strideM = strideM
        self.activityClass = activityClass
        self.movementSeconds = min(durationSeconds, max(0, movementSeconds ?? durationSeconds))
        self.hasMovementCoverage = hasMovementCoverage
        self.isWorkout = isWorkout
        self.workoutKind = workoutKind
        self.workoutOnFoot = workoutOnFoot
        self.workoutTableMET = workoutTableMET
        self.isSleep = isSleep
        self.isOffWrist = isOffWrist
    }
}

public struct WhoopEnergyBucketResult: Equatable, Sendable {
    public let start: Int
    public let kcal: Double
    public let activeKcal: Double
    public let evidence: EnergyEvidence
    public let context: EnergyContext
    public let uncertaintyFraction: Double
}

public struct WhoopDailyEnergyEstimate: Equatable, Sendable {
    /// v9 (2026-09-30): an Apple Watch VO₂max reading stands for 183 days instead of 30
    /// (`PeakMETResolver.appleFreshnessDays`), so a rarely worn Watch keeps pricing workouts from the
    /// wearer's own measurement instead of Jurca's estimate. Bumped because stored days after a reading
    /// expired carry the estimate as their ceiling.
    ///
    /// v8 (2026-09-29): the aerobic ceiling a confirmed workout is scaled to is an INPUT
    /// (`PeakMETResolver`: an entered value, a fresh Apple Watch reading, else Jurca 2005) instead of
    /// Uth's 15.3 · HRmax / HRrest bounded to 7–16 MET. Uth has no body term and is validated in trained
    /// men only; for a 212 kg wearer measured at 19 ml/kg/min it read 47, and walks were priced at three
    /// times what the Watch and the ACSM walking equation give. Also v8: a session on foot with movement
    /// evidence is priced by pace, as ordinary walking already was, with heart rate as the same bounded
    /// correction; and a workout with no ceiling yet is priced from the sport's Compendium MET.
    ///
    /// v7 (2026-09-26): the workout context now comes from every session the app lists — the native
    /// strength logger, Hevy API sync and the FitNotes/Strong history import, all retained straps and
    /// the detector's dismissals — instead of a hand-kept list of storage
    /// namespaces that had none of the first three. A 90-minute native strength session was
    /// therefore priced as `unresolvedElevatedHR`, i.e. zero active energy, while the burn-rate chart
    /// drew it as a training band. The model itself is unchanged; the same day's inputs now carry the
    /// sessions they always should have, so their stored figures must be recomputed.
    ///
    /// Also v7: a confirmed workout is priced by `exerciseMET` — the ACSM heart-rate-reserve relation
    /// with a per-kind share — instead of `1 + c·HRR²`. The quadratic had no source and priced a
    /// 108-bpm lifting session at ~2 MET, below the Compendium's 3.5 for light resistance training,
    /// and a 155-bpm run at ~7 MET where the running itself costs ~10.
    ///
    /// v6 (2026-09-10): the cadence branch of `movementMET` prices steps with the wearer's own
    /// measured step length instead of a 0.75 m population average. Bumped because the same day's
    /// inputs now yield a different figure; days with no measurement keep the old value exactly.
    ///
    /// v5 (2026-08-29): heart rate without independently confirmed movement or a workout contributes
    /// no active energy. Locomotion is charged only for its observed movement seconds rather than the
    /// entire five-minute bucket. Bumped so every v4 physiological allowance is recomputed away.
    public static let modelVersion = "whoop-bucket-v9"

    public let totalKcal: Double
    public let observedSeconds: Int
    public let inferredSeconds: Int
    public let modeledSeconds: Int
    public let physiologicalSeconds: Int
    public let contextSeconds: [EnergyContext: Int]
    /// Symmetric approximate uncertainty, expressed as a fraction of total energy.
    public let uncertaintyFraction: Double
    public let buckets: [WhoopEnergyBucketResult]
    /// Seconds of moderate-or-harder activity inside bouts of at least 20 minutes: movement at 3 MET or
    /// more by measured pace (or classified as a run), or a workout at 40 % of the heart-rate reserve or more (ACSM's lower bound for
    /// moderate). Feeds the Jurca activity category. A workout is judged by its reserve rather than its
    /// MET because its MET is itself scaled to the ceiling this figure helps estimate.
    public let aerobicSeconds: Int
    /// Whether the day held at least ten continuous minutes of movement or workout.
    public let hadLightActivity: Bool

    /// Wall-clock seconds whose basal share is already present in `totalKcal`. This is the denominator
    /// `EnergyEngine` must use when topping up the unmodelled remainder of a day; using HR coverage here
    /// would add basal twice for movement-backed or otherwise modelled seconds without optical samples.
    public var representedSeconds: Int {
        observedSeconds + inferredSeconds + physiologicalSeconds + modeledSeconds
    }

    public var coverageFraction: Double {
        let total = representedSeconds
        return total > 0 ? Double(observedSeconds + physiologicalSeconds) / Double(total) : 0
    }
}

/// Pure WHOOP-first energy model. Apple Health is deliberately absent from these inputs: it is a
/// reference/calibration stream and cannot silently replace or be added to the strap estimate.
public enum WhoopEnergyModel {
    public static let defaultBucketSeconds = 300

    /// Continuous span a bout must last to count toward `aerobicSeconds`.
    static let aerobicBoutSeconds = 1_200
    /// Continuous span of movement that makes a day count as lightly active.
    static let lightBoutSeconds = 600
    /// Share of the heart-rate reserve at which a workout counts as moderate (ACSM).
    static let moderateReserve = 0.40
    /// Pace-derived MET at which movement counts as moderate.
    static let moderateMET = 3.0

    /// - Parameter peakMET: the wearer's aerobic ceiling for the day (`PeakMETResolver`). Nil prices
    ///   confirmed workouts from their sport's Compendium MET instead of from heart rate.
    public static func estimate(buckets: [WhoopEnergyBucket], profile: UserProfile,
                                restingHR: Double?, maxHR: Double?, flexHR: Double? = nil,
                                peakMET: Double? = nil)
        -> WhoopDailyEnergyEstimate? {
        guard let bmr = Calories.bmrKcalPerDay(profile: profile), profile.weightKg > 0 else { return nil }
        let valid = buckets
            .filter { $0.durationSeconds > 0 && $0.durationSeconds <= 900 }
            .sorted { $0.start < $1.start }
        guard !valid.isEmpty else { return nil }

        let basalPerSecond = bmr / 86_400
        var results: [WhoopEnergyBucketResult] = []
        var observed = 0
        var inferred = 0
        var physiological = 0
        var modeled = 0
        var contextSeconds: [EnergyContext: Int] = [:]
        // Per bucket: seconds that count as moderate, and seconds of any movement or workout.
        var moderateByBucket: [Int] = []
        var movingByBucket: [Int] = []

        for bucket in valid {
            let seconds = bucket.durationSeconds
            let hrSeconds = min(seconds, max(0, bucket.hrCoverageSeconds))
            let basal = basalPerSecond * Double(seconds)
            let result: WhoopEnergyBucketResult
            let hr = finite(bucket.averageHR).flatMap { (30...240).contains($0) ? $0 : nil }
            let resting = min(100, max(35, restingHR ?? 60))
            let maximum = max(resting + 20, maxHR ?? 190)
            let flex = min(maximum, max(resting, flexHR ?? resting + 20))
            let movesOnFoot = bucket.isWorkout && bucket.workoutOnFoot && hasMovement(bucket)
            var moderate = 0
            var moving = 0

            if bucket.isOffWrist {
                result = bucketResult(bucket, basal: basal, active: 0, evidence: .modeled,
                                      context: .offWrist, uncertainty: 0.30)
                modeled += seconds
            } else if bucket.isSleep {
                result = bucketResult(bucket, basal: basal, active: 0, evidence: .modeled,
                                      context: .sleep, uncertainty: 0.20)
                modeled += seconds
            } else if bucket.isWorkout, let hr, !movesOnFoot {
                if let peakMET {
                    let met = exerciseMET(hr: hr, resting: resting, maximum: maximum,
                                          kind: bucket.workoutKind, peakMET: peakMET)
                    let active = activeKcal(met: met, seconds: seconds, weightKg: profile.weightKg)
                    result = bucketResult(bucket, basal: basal, active: active, evidence: .observed,
                                          context: .confirmedWorkout, uncertainty: 0.18)
                    observed += hrSeconds
                    inferred += seconds - hrSeconds
                } else {
                    // No ceiling yet (no resting HR, nothing measured): the sport's published cost,
                    // which knows what the activity usually costs rather than what this one did.
                    let met = bucket.workoutTableMET ?? ActivityMETCatalog.defaultMET
                    let active = activeKcal(met: met, seconds: seconds, weightKg: profile.weightKg)
                    result = bucketResult(bucket, basal: basal, active: active, evidence: .inferred,
                                          context: .confirmedWorkout, uncertainty: 0.30)
                    inferred += seconds
                }
                moving = seconds
                if reserveFraction(hr: hr, resting: resting, maximum: maximum) >= moderateReserve {
                    moderate = seconds
                }
            } else if hasMovement(bucket) {
                let movementSeconds = min(seconds, max(0, bucket.movementSeconds))
                let movement = movementMET(bucket)
                // Locomotion is anchored to speed/cadence. HR can make a bounded secondary correction,
                // but cannot turn an ordinary walk into a maximal-effort bucket.
                let met: Double
                if let hr {
                    let exercise = locomotionHRMET(hr: hr, resting: resting, maximum: maximum)
                    met = min(14.5, movement + min(1.5, max(0, exercise - movement) * 0.25))
                } else {
                    met = movement
                }
                let active = activeKcal(met: met, seconds: movementSeconds,
                                        weightKg: profile.weightKg)
                // A walk logged as a session stays the session, so its window reads as training;
                // only the price follows the pace.
                result = bucketResult(bucket, basal: basal, active: active,
                                      evidence: hr == nil ? .inferred : .observed,
                                      context: movesOnFoot ? .confirmedWorkout : .locomotion,
                                      uncertainty: hr == nil ? 0.28 : 0.20)
                moving = movementSeconds
                // Pace, not the class floor, decides moderate; a classified run is moderate outright.
                if (paceMET(bucket) ?? 0) >= moderateMET || bucket.activityClass == 2 {
                    moderate = movementSeconds
                }
                if hr == nil {
                    inferred += seconds
                } else {
                    observed += hrSeconds
                    inferred += seconds - hrSeconds
                }
            } else if let hr {
                let context: EnergyContext
                if bucket.hasMovementCoverage {
                    context = hr > flex ? .unresolvedElevatedHR : .sedentary
                } else {
                    context = .unknown
                }
                result = bucketResult(bucket, basal: basal, active: 0,
                                      evidence: .physiological, context: context,
                                      uncertainty: context == .unknown ? 0.40 : 0.35)
                physiological += hrSeconds
                modeled += seconds - hrSeconds
            } else if bucket.hasMovementCoverage {
                result = bucketResult(bucket, basal: basal, active: 0, evidence: .modeled,
                                      context: .sedentary, uncertainty: 0.30)
                modeled += seconds
            } else {
                result = bucketResult(bucket, basal: basal, active: 0, evidence: .modeled,
                                      context: .unknown, uncertainty: 0.45)
                modeled += seconds
            }
            contextSeconds[result.context, default: 0] += seconds
            results.append(result)
            moderateByBucket.append(moderate)
            movingByBucket.append(moving)
        }
        let aerobic = boutSeconds(valid, counted: moderateByBucket, minimumSpan: aerobicBoutSeconds)
        let light = boutSeconds(valid, counted: movingByBucket, minimumSpan: lightBoutSeconds)

        let total = results.reduce(0) { $0 + $1.kcal }
        let duration = max(1, observed + inferred + physiological + modeled)
        let uncertaintyNumerator = zip(results, valid).reduce(0.0) { partial, pair in
            partial + pair.0.uncertaintyFraction * Double(pair.1.durationSeconds)
        }
        let uncertainty = min(0.60, uncertaintyNumerator / Double(duration))
        return .init(totalKcal: total, observedSeconds: observed, inferredSeconds: inferred,
                     modeledSeconds: modeled, physiologicalSeconds: physiological,
                     contextSeconds: contextSeconds, uncertaintyFraction: uncertainty, buckets: results,
                     aerobicSeconds: aerobic, hadLightActivity: light > 0)
    }

    /// Counted seconds inside runs of back-to-back buckets whose wall-clock span reaches `minimumSpan`.
    ///
    /// The span decides whether a run is a bout; the counted seconds are what it contributes. A walk
    /// that fills 250 s of each of four buckets is a 20-minute bout worth 1,000 s, not a missed bout.
    static func boutSeconds(_ buckets: [WhoopEnergyBucket], counted: [Int], minimumSpan: Int) -> Int {
        var total = 0
        var runSpan = 0
        var runCounted = 0
        var runEnd: Int?
        func close() {
            if runSpan >= minimumSpan { total += runCounted }
            runSpan = 0
            runCounted = 0
            runEnd = nil
        }
        for (bucket, seconds) in zip(buckets, counted) {
            guard seconds > 0 else { close(); continue }
            if let end = runEnd, bucket.start != end { close() }
            runSpan += bucket.durationSeconds
            runCounted += seconds
            runEnd = bucket.start + bucket.durationSeconds
        }
        close()
        return total
    }

    private static func bucketResult(_ bucket: WhoopEnergyBucket, basal: Double, active: Double,
                                     evidence: EnergyEvidence, context: EnergyContext,
                                     uncertainty: Double) -> WhoopEnergyBucketResult {
        .init(start: bucket.start, kcal: basal + active, activeKcal: active, evidence: evidence,
              context: context, uncertaintyFraction: uncertainty)
    }

    private static func finite(_ value: Double?) -> Double? {
        guard let value, value.isFinite else { return nil }
        return value
    }

    /// Whether this bucket carries any INDEPENDENT movement signal. Load-bearing as a guard rather
    /// than a hint: `movementMET` floors at 1.5 even with nothing to go on, so calling it
    /// unconditionally would credit every still, awake, measured-HR bucket half a MET of invented
    /// activity — over a mostly-sedentary day that is hundreds of phantom kcal.
    private static func hasMovement(_ bucket: WhoopEnergyBucket) -> Bool {
        (bucket.steps ?? 0) > 0 || (finite(bucket.distanceM) ?? 0) > 0
            || (finite(bucket.motionIntensity) ?? 0) > 0.03
            || (bucket.activityClass ?? 0) > 0
    }

    /// Walking/running speed -> MET, piecewise-linear between published reference points
    /// (Ainsworth et al., "2011 Compendium of Physical Activities" — the standard reference table
    /// for activity METs). Replaces two independently-tuned tables (one for GPS distance/speed, one
    /// for step cadence) that disagreed with each other, and with the Compendium, by up to 2.7 MET
    /// at the same real speed — see `fork/decisions.md`, 2026-08-26. Strictly increasing in both
    /// columns; `metForSpeed` relies on that for its interpolation.
    private static let speedMETTable: [(kmh: Double, met: Double)] = [
        (0.0, 1.5),
        (3.2, 2.8), (4.0, 3.0), (4.8, 3.5), (5.6, 4.3), (6.4, 5.0), (7.2, 7.0),
        // Running overtakes "very brisk walking" here — a real physiological crossover (race-walking
        // at that pace costs more than an easy jog), not a smoothing artifact.
        (8.0, 8.3), (9.7, 9.8), (11.3, 11.0), (12.9, 11.8), (14.5, 12.8), (16.1, 14.5),
    ]

    /// Package-internal rather than private: `EnergyEngine`'s step fallback prices a day with no
    /// device energy on this SAME curve. Two step-to-energy tables in one module is the state this
    /// table was introduced to end.
    static func metForSpeed(_ kmh: Double) -> Double {
        guard let first = speedMETTable.first, let last = speedMETTable.last else { return 1.5 }
        if kmh <= first.kmh { return first.met }
        if kmh >= last.kmh { return last.met }
        for (a, b) in zip(speedMETTable, speedMETTable.dropFirst()) where kmh <= b.kmh {
            let t = (kmh - a.kmh) / (b.kmh - a.kmh)
            return a.met + (b.met - a.met) * t
        }
        return last.met
    }

    private static func movementMET(_ bucket: WhoopEnergyBucket) -> Double {
        var met = paceMET(bucket) ?? motionMET(bucket)
        // The strap's own classification is stronger evidence than a cadence bucket derived from a
        // motion-tick counter, so it raises a floor rather than being averaged in. It never LOWERS a
        // higher estimate: a run misreported as a walk keeps the faster distance/cadence answer.
        switch bucket.activityClass {
        case 1: met = max(met, 3.0)   // walk
        case 2: met = max(met, 7.0)   // run
        default: break
        }
        return met
    }

    /// MET from measured ground speed (distance, else cadence), or nil when neither was measured.
    ///
    /// Separate from `movementMET` because the activity category reads pace alone: the strap's walk
    /// class floors energy at 3 MET so a classified walk is never priced below one, but that floor says
    /// nothing about how brisk the walk was, and would make every stroll count as moderate exercise.
    private static func paceMET(_ bucket: WhoopEnergyBucket) -> Double? {
        let minutes = max(1.0 / 60, Double(bucket.movementSeconds) / 60)
        if let distance = finite(bucket.distanceM), distance > 0 {
            let speedKmh = distance / 1_000 / (minutes / 60)
            return metForSpeed(speedKmh)
        }
        if let steps = bucket.steps, steps > 0 {
            let cadence = Double(steps) / minutes
            // Step length folds cadence onto the SAME curve the distance branch uses, rather than
            // maintaining a second, independently-tuned table that can drift away from it again.
            // It is the wearer's OWN measured step when one is available and the population average
            // otherwise — and that fallback is the exact 0.75 m this branch has always used, so a
            // wearer the phone never measured is priced today the way they were yesterday.
            return metForSpeed(cadence * StrideLength.metersPerStep(bucket.strideM) * 60 / 1_000)
        }
        return nil
    }

    /// Coarse fallback when neither distance nor cadence is available — gravity-derived motion only.
    private static func motionMET(_ bucket: WhoopEnergyBucket) -> Double {
        let motion = finite(bucket.motionIntensity) ?? 0
        return motion >= 0.20 ? 3.0 : motion >= 0.08 ? 2.0 : 1.5
    }

    /// Metabolic cost above rest for a whole bucket, in kcal. One conversion site so the HR,
    /// movement and corroborated paths can never drift apart on the MET→kcal arithmetic.
    private static func activeKcal(met: Double, seconds: Int, weightKg: Double) -> Double {
        activeKcal(met: met, seconds: Double(seconds), weightKg: weightKg)
    }

    /// The same conversion for a span of any length — `WorkoutEnergyEstimate` prices a whole session
    /// on it, so the session tile and the buckets agree on what one MET-minute costs.
    static func activeKcal(met: Double, seconds: Double, weightKg: Double) -> Double {
        max(0, met - 1) * 3.5 * weightKg / 200 * (seconds / 60)
    }

    /// The MET a confirmed workout runs at, from heart rate.
    ///
    /// ACSM's working relation between heart-rate reserve and oxygen-uptake reserve (Swain &
    /// Leutholtz 1997): `%VO2R ≈ %HRR`, so `MET = 1 + %HRR · (peakMET − 1)`, scaled by the kind's
    /// `vo2ReserveShare`. Linear, so a session's average heart rate prices it exactly as its buckets
    /// would, and continuous, with no step anywhere in the range.
    ///
    /// Only ever reached inside an independently confirmed workout — the context selection upstream
    /// is what keeps an unexplained high heart rate from being charged as exercise, which is the
    /// failure the old whole-day HR model was withdrawn for.
    ///
    /// `peakMET` is the wearer's ceiling from `PeakMETResolver`. It used to be derived here from Uth's
    /// heart-rate ratio, which knows nothing of body size; see `WhoopDailyEnergyEstimate.modelVersion`.
    public static func exerciseMET(hr: Double, resting: Double, maximum: Double,
                                   kind: EnergyWorkoutKind, peakMET: Double) -> Double {
        guard maximum > resting, peakMET.isFinite else { return 1 }
        let reserve = reserveFraction(hr: hr, resting: resting, maximum: maximum)
        return min(14.5, 1 + kind.vo2ReserveShare * reserve * (max(1, peakMET) - 1))
    }

    /// Share of the heart-rate reserve, bounded to 0…1.
    static func reserveFraction(hr: Double, resting: Double, maximum: Double) -> Double {
        guard maximum > resting else { return 0 }
        return min(1, max(0, (hr - resting) / (maximum - resting)))
    }

    /// The bounded heart-rate nudge a LOCOMOTION bucket may take on top of its movement MET.
    ///
    /// Deliberately still the pre-v7 curve. This is not a workout price but a secondary correction
    /// on every walking minute of the day, and it was sized against this curve; moving it with
    /// `exerciseMET` would raise ordinary walking across the whole day, which is a separate question
    /// from how a confirmed workout is priced.
    private static func locomotionHRMET(hr: Double, resting: Double, maximum: Double) -> Double {
        let reserve = min(1, max(0, (hr - resting) / (maximum - resting)))
        return min(14.5, 1 + 11 * reserve * reserve)
    }

}

public struct CausalWeightObservation: Equatable, Sendable {
    public enum Source: Int, Equatable, Sendable { case health = 0, manual = 1 }
    public let timestamp: Int
    public let weightKg: Double
    public let source: Source

    public init(timestamp: Int, weightKg: Double, source: Source) {
        self.timestamp = timestamp
        self.weightKg = weightKg
        self.source = source
    }
}

public enum CausalWeightResolver {
    /// Ten-day EWMA using observations available at or before the requested instant. A manual entry
    /// wins over Health on the same local day. Values are carried for at most 90 days; otherwise the
    /// caller's profile fallback is returned at lower confidence by the caller.
    public static func weight(at timestamp: Int, observations: [CausalWeightObservation],
                              calendar: Calendar = .current) -> Double? {
        let eligible = observations.filter {
            $0.timestamp <= timestamp && $0.weightKg.isFinite && (25...350).contains($0.weightKg)
        }
        var byDay: [Date: CausalWeightObservation] = [:]
        for row in eligible.sorted(by: { $0.timestamp < $1.timestamp }) {
            let day = calendar.startOfDay(for: Date(timeIntervalSince1970: TimeInterval(row.timestamp)))
            if let old = byDay[day], old.source.rawValue > row.source.rawValue { continue }
            byDay[day] = row
        }
        let rows = byDay.sorted { $0.key < $1.key }
        guard let last = rows.last,
              timestamp - Int(last.key.timeIntervalSince1970) <= 90 * 86_400 else { return nil }
        let alpha = 2.0 / 11.0
        return rows.reduce(nil as Double?) { smoothed, item in
            guard let smoothed else { return item.value.weightKg }
            return alpha * item.value.weightKg + (1 - alpha) * smoothed
        }
    }
}

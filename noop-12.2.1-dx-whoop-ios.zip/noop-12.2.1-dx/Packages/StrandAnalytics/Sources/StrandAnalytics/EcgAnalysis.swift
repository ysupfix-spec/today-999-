import Foundation

/// Measurements from one single-lead ECG strip, as the WHOOP MG records it: 100 Hz filtered samples in
/// (nominal) microvolts, about 30 s long, taken between the wrist and a finger of the other hand.
///
/// The pipeline follows what ECG software commonly does, scaled to what one lead at 100 Hz supports:
///
/// 1. Baseline removal with two cascaded median filters (200 ms, then 600 ms), the de Chazal approach:
///    it removes wander without bending the P and T waves the way a plain moving mean does.
/// 2. QRS detection on slope energy (derivative, squared, 150 ms moving window), the core of
///    Pan-Tompkins, with a 250 ms refractory period. The R peak is then placed on the trace itself, and
///    the dominant QRS polarity is detected so an inverted lead still measures.
/// 3. Rhythm: RR intervals, irregular beats (an RR more than 20 % off its local median), and HRV
///    (RMSSD, SDNN, pNN50) over normal-to-normal intervals only.
/// 4. A median beat from the regular beats that correlate with it (r >= 0.9). Averaging is what makes
///    the small P and T waves measurable on a wrist lead.
/// 5. Fiducial points on the median beat: QRS onset and J point by slope threshold, P onset and T end by
///    the tangent method; PR, QRS, QT, and QTc by Fridericia (and Bazett for reference).
///
/// Limits that stay true whatever the code does: 100 Hz sampling gives about 10 ms of resolution (a
/// diagnostic ECG samples at 500 Hz or more), one lead gives no electrical axis and no localisation, and
/// the strap's own filter and amplitude scale are not verified. Every interval is a nominal estimate, not
/// a clinical measurement, and nothing here is a diagnosis.
public enum EcgAnalysis {

    /// Points on the median beat, in milliseconds relative to the R peak.
    public struct Fiducials: Equatable, Sendable {
        public let pOnsetMs: Double?
        public let pPeakMs: Double?
        public let qrsOnsetMs: Double
        public let jPointMs: Double
        public let tPeakMs: Double?
        public let tEndMs: Double?
    }

    public struct Result: Equatable, Sendable {
        public let beatsDetected: Int
        public let irregularBeats: Int
        public let meanHeartRate: Double
        public let minHeartRate: Double
        public let maxHeartRate: Double
        public let rmssdMs: Double?
        public let sdnnMs: Double?
        /// Percent of successive normal-to-normal differences above 50 ms.
        public let pnn50: Double?
        /// The dominant QRS deflection is negative (a reversed lead or the other wrist).
        public let inverted: Bool
        /// Beats that went into the median beat.
        public let beatsAveraged: Int
        /// Median correlation of the averaged beats with the median beat, 0 to 1.
        public let templateCorrelation: Double?
        /// The median beat in microvolts at the input rate, polarity as recorded.
        public let template: [Double]
        /// Index of the R peak in `template`.
        public let templateRIndex: Int
        public let fiducials: Fiducials?
        public let prMs: Double?
        public let qrsMs: Double?
        public let qtMs: Double?
        public let qtcFridericiaMs: Double?
        public let qtcBazettMs: Double?
    }

    /// Fewer regular beats than this and no median beat (or interval) is reported.
    public static let minimumBeats = 8
    static let correlationFloor = 0.8

    /// The WHOOP MG's live ECG stream behaves like a first-order high-pass at about this cutoff. Measured on
    /// one wearer on 2026-10-08: three strap readings each followed within two minutes by an Apple Watch
    /// ECG on the same wrist; passing the Watch strip through this filter reproduced the strap's median beat
    /// (RMS 75-116 down to 30-33 µV), and each pair on its own put the best cutoff at 1.5 to 1.75 Hz. It
    /// is the strap's filter, not NOOP's: it deepens the dip after the R wave and flattens the T wave.
    public static let strapHighPassHz = 1.5

    /// `compensatingHighPassHz` undoes a first-order high-pass at that cutoff before anything is measured,
    /// for a stream known to carry one (`strapHighPassHz` for the MG). A 0.05 Hz high-pass, the usual
    /// diagnostic lower corner, is left in place so the inverse cannot drift.
    public static func analyze(_ samples: [Int16?], sampleRate: Int = 100,
                               compensatingHighPassHz: Double? = nil) -> Result? {
        guard sampleRate == 100, samples.count >= sampleRate * 8 else { return nil }
        if let cutoff = compensatingHighPassHz, cutoff > 0 {
            return analyze(undoHighPass(samples, cutoffHz: cutoff, sampleRate: Double(sampleRate)),
                           sampleRate: sampleRate)
        }
        let fs = Double(sampleRate)
        func n(_ seconds: Double) -> Int { max(1, Int((seconds * fs).rounded())) }

        // Digital saturation and isolated, extreme impulses must not set the detection threshold.
        // Scale is relative to the strip: the device's physical amplitude calibration is unknown.
        let present = samples.compactMap { $0.map(Double.init) }
        guard !present.isEmpty else { return nil }
        let centre = median(present)
        let amplitude = percentile(present.map { abs($0 - centre) }, 0.99)
        guard amplitude > 0 else { return nil }
        var clean = samples
        for k in samples.indices {
            guard let raw = samples[k] else { continue }
            if abs(Int(raw)) >= 32_760 || abs(Double(raw) - centre) > 6 * amplitude {
                for j in max(0, k - n(0.08))...min(samples.count - 1, k + n(0.08)) { clean[j] = nil }
            }
        }

        // 1. Baseline removal, per contiguous run (a lost packet is a gap, never bridged).
        var y = [Double?](repeating: nil, count: samples.count)
        var runs: [Range<Int>] = []
        var i = 0
        while i < samples.count {
            guard clean[i] != nil else { i += 1; continue }
            var end = i
            while end < samples.count, clean[end] != nil { end += 1 }
            let run = (i..<end).map { Double(clean[$0]!) }
            if run.count >= n(2) {
                let baseline = medianFilter(medianFilter(run, width: n(0.2) | 1), width: n(0.6) | 1)
                for k in run.indices { y[i + k] = run[k] - baseline[k] }
                runs.append(i..<end)
            }
            i = end
        }
        guard !runs.isEmpty else { return nil }

        // 2. QRS detection on slope energy, then R placed on the trace.
        var candidates: [(index: Int, signed: Double, run: Int)] = []
        for (runIndex, run) in runs.enumerated() {
            let x = run.map { y[$0]! }
            var energy = [Double](repeating: 0, count: x.count)
            for k in 2..<max(2, x.count) {
                let d = x[k] - x[k - 2]
                energy[k] = d * d
            }
            let window = n(0.15)
            var mwi = [Double](repeating: 0, count: x.count)
            var acc = 0.0
            for k in energy.indices {
                acc += energy[k]
                if k >= window { acc -= energy[k - window] }
                mwi[k] = acc / Double(window)
            }
            let threshold = 0.2 * percentile(mwi, 0.98)
            guard threshold > 0 else { continue }
            var peaks: [Int] = []
            for k in 1..<max(1, mwi.count - 1) where mwi[k] > threshold && mwi[k] >= mwi[k - 1] && mwi[k] > mwi[k + 1] {
                if let last = peaks.last, k - last < n(0.25) {
                    if mwi[k] > mwi[last] { peaks[peaks.count - 1] = k }
                } else {
                    peaks.append(k)
                }
            }
            for peak in peaks {
                let lo = max(0, peak - n(0.2))
                let r = (lo...peak).max { abs(x[$0]) < abs(x[$1]) } ?? peak
                candidates.append((run.lowerBound + r, x[r], runIndex))
            }
        }
        guard candidates.count >= 3 else { return nil }
        let polarity: Double = median(candidates.map(\.signed)) < 0 ? -1 : 1
        // Re-place each R on the dominant deflection, so a deep S never stands in for the R.
        var placed: [(index: Int, run: Int, height: Double)] = []
        for c in candidates {
            let lo = max(runs[c.run].lowerBound, c.index - n(0.06))
            let hi = min(runs[c.run].upperBound - 1, c.index + n(0.06))
            let r = (lo...hi).max { polarity * y[$0]! < polarity * y[$1]! } ?? c.index
            placed.append((r, c.run, polarity * y[r]!))
        }
        // A second, amplitude stage as in Pan-Tompkins' signal and noise levels: on a noisy strip (muscle
        // tremor on the clasp) the slope energy also peaks on noise bursts, whose R height is a fraction of
        // a real beat's. Real beats are the majority, so their median sets the level.
        let typicalHeight = median(placed.map(\.height))
        var beats: [(index: Int, run: Int)] = []
        var lastHeight = 0.0
        for p in placed where p.height >= 0.5 * typicalHeight {
            if let last = beats.last, last.run == p.run, p.index - last.index < n(0.25) {
                if p.height > lastHeight { beats[beats.count - 1] = (p.index, p.run); lastHeight = p.height }
                continue
            }
            beats.append((p.index, p.run))
            lastHeight = p.height
        }
        guard beats.count >= 3 else { return nil }

        // Refine the timing of an already detected R using its immediate neighbours. Keeping every
        // R on the 10 ms input grid manufactures RMSSD even for perfectly constant off-grid RR.
        // The parabola changes timing only: detection, template alignment and morphology retain their
        // integer indices. It adds no bandwidth and is not a claim of sub-sample physical accuracy.
        let positions = beats.map { beat -> Double in
            let index = beat.index, run = runs[beat.run]
            guard index > run.lowerBound, index + 1 < run.upperBound else { return Double(index) }
            return Double(index) + peakOffset(left: polarity * y[index - 1]!,
                                               center: polarity * y[index]!,
                                               right: polarity * y[index + 1]!)
        }

        // 3. Rhythm and HRV. Intervals never span a gap.
        var rr: [(ms: Double, beat: Int)] = []
        for k in 1..<beats.count where beats[k].run == beats[k - 1].run {
            rr.append(((positions[k] - positions[k - 1]) * 1000 / fs, k))
        }
        guard !rr.isEmpty else { return nil }
        var irregular = Set<Int>()       // indices into `rr`
        for k in rr.indices {
            let neighbours = rr[max(0, k - 4)..<k].map(\.ms) + rr[min(rr.count, k + 1)..<min(rr.count, k + 5)].map(\.ms)
            guard !neighbours.isEmpty else { continue }
            let local = median(neighbours)
            if abs(rr[k].ms - local) > 0.2 * local { irregular.insert(k) }
        }
        let normal = rr.indices.filter { !irregular.contains($0) && !irregular.contains($0 - 1) }
        let nn = normal.map { rr[$0].ms }
        var successive: [Double] = []
        for k in normal where normal.contains(k - 1) && rr[k].beat - 1 == rr[k - 1].beat {
            successive.append(rr[k].ms - rr[k - 1].ms)
        }
        let allRR = rr.map(\.ms)
        let rateBasis = nn.isEmpty ? allRR : nn
        let meanRR = allRR.reduce(0, +) / Double(allRR.count)
        let rmssd = successive.count >= 2
            ? (successive.map { $0 * $0 }.reduce(0, +) / Double(successive.count)).squareRoot() : nil
        let sdnn: Double? = nn.count >= 3 ? standardDeviation(nn) : nil
        let pnn50: Double? = successive.count >= 2
            ? 100 * Double(successive.filter { abs($0) > 50 }.count) / Double(successive.count) : nil

        // 4. Median beat from the regular beats that look like it.
        let pre = n(0.35), post = n(0.55)
        // Every beat is a candidate, irregular timing included: a premature beat with a different shape
        // fails the correlation below, while an irregular rhythm (atrial fibrillation) keeps normal QRS
        // shapes and must still get a median beat. Excluding by timing would leave such a strip without
        // any rhythm values at all, because the shape gate below requires a median beat.
        var windows: [[Double]] = []
        for beat in beats {
            let run = runs[beat.run]
            guard beat.index - pre >= run.lowerBound, beat.index + post < run.upperBound else { continue }
            let iso = median((beat.index - n(0.07)...beat.index - n(0.03)).map { y[$0]! })
            windows.append((beat.index - pre...beat.index + post).map { y[$0]! - iso })
        }
        var template: [Double] = []
        var averaged = 0
        var correlation: Double?
        if windows.count >= minimumBeats {
            let first = columnMedian(windows)
            let scored = windows.map { (window: $0, r: pearson($0, first)) }
            let kept = scored.filter { $0.r >= correlationFloor }
            if kept.count >= minimumBeats {
                template = columnMedian(kept.map(\.window))
                averaged = kept.count
                correlation = median(kept.map(\.r))
            }
        }

        // Repeated shape agreement is required for rhythm too. Random noise can produce energy peaks
        // and plausible RR intervals; it must not receive HR/HRV merely because it crossed a threshold.
        guard !template.isEmpty, (300...2000).contains(median(allRR)) else { return nil }

        // 5. Fiducials and intervals on the median beat.
        var fiducials: Fiducials?
        var pr: Double?, qrs: Double?, qt: Double?, qtcF: Double?, qtcB: Double?
        if !template.isEmpty {
            fiducials = locateFiducials(template.map { polarity * $0 }, rIndex: pre, fs: fs, meanRRms: meanRR)
            // PR from the wavelet delineator: on the QT Database it finds the P onset in 98 to 100 % of
            // windows (the slope method above: 56 to 77 %) at the same accuracy, and on the strap it
            // brings PR to within 12 ms of an Apple Watch instead of 40 to 70 ms short. Its QRS onset
            // pairs with its own P onset; QT keeps the onset of `locateFiducials`, which measured better.
            // The paper's P significance is relative to the search window alone, so a beat with no P wave
            // (atrial fibrillation) still yields one out of the noise. A P wave has to reach 4 % of the R
            // wave on the median beat (it is typically 5 to 15 %), or no PR is reported.
            let wavelet = (sampleRate == 100 ? WaveletDelineator.pWave(template, rIndex: pre, meanRRms: meanRR) : nil)
                .flatMap { w -> (pOnsetMs: Double, qrsOnsetMs: Double)? in
                    let lo = max(0, pre + Int((w.pOnsetMs / 1000 * fs).rounded()))
                    // up to 20 ms before the QRS onset, where the paper's own P search window ends
                    let hi = min(template.count - 1, pre + Int(((w.qrsOnsetMs - 20) / 1000 * fs).rounded()))
                    guard lo < hi else { return nil }
                    let segment = template[lo...hi]
                    let height = (segment.max() ?? 0) - (segment.min() ?? 0)
                    return height >= 0.04 * abs(template[pre]) ? w : nil
                }
            if let f = fiducials {
                fiducials = Fiducials(pOnsetMs: wavelet.map { $0.pOnsetMs } ?? f.pOnsetMs, pPeakMs: f.pPeakMs,
                                      qrsOnsetMs: f.qrsOnsetMs, jPointMs: f.jPointMs, tPeakMs: f.tPeakMs,
                                      tEndMs: f.tEndMs)
            }
            if let f = fiducials {
                let rrSeconds = (nn.isEmpty ? meanRR : nn.reduce(0, +) / Double(nn.count)) / 1000
                if let w = wavelet {
                    pr = within(w.qrsOnsetMs - w.pOnsetMs, 80...320)
                } else if let pOn = f.pOnsetMs {
                    pr = within(f.qrsOnsetMs - pOn, 80...320)
                }
                qrs = within(f.jPointMs - f.qrsOnsetMs, 40...200)
                if let tEnd = f.tEndMs, let value = within(tEnd - f.qrsOnsetMs, 200...650) {
                    qt = value
                    qtcF = value / pow(rrSeconds, 1.0 / 3.0)
                    qtcB = value / rrSeconds.squareRoot()
                }
            }
        }

        let rates = rateBasis.map { 60_000 / $0 }
        return Result(beatsDetected: beats.count, irregularBeats: irregular.count,
                      meanHeartRate: 60_000 / meanRR, minHeartRate: rates.min() ?? 0,
                      maxHeartRate: rates.max() ?? 0, rmssdMs: rmssd, sdnnMs: sdnn, pnn50: pnn50,
                      inverted: polarity < 0, beatsAveraged: averaged, templateCorrelation: correlation,
                      template: template, templateRIndex: pre, fiducials: fiducials, prMs: pr, qrsMs: qrs,
                      qtMs: qt, qtcFridericiaMs: qtcF, qtcBazettMs: qtcB)
    }

    // MARK: - Fiducial points

    /// `z` is the median beat with its R pointing up. Searches run on a 4x linear upsample, which places a
    /// threshold crossing between samples; it does not add information the 100 Hz trace does not carry.
    static func locateFiducials(_ z: [Double], rIndex: Int, fs: Double, meanRRms: Double) -> Fiducials? {
        let up = 4
        var u: [Double] = []
        u.reserveCapacity(z.count * up)
        for k in 0..<(z.count - 1) {
            for j in 0..<up { u.append(z[k] + (z[k + 1] - z[k]) * Double(j) / Double(up)) }
        }
        u.append(z[z.count - 1])
        let r0 = rIndex * up
        func s(_ seconds: Double) -> Int { Int((seconds * fs * Double(up)).rounded()) }
        func ms(_ index: Double) -> Double { (index - Double(r0)) * 1000 / (fs * Double(up)) }
        var slope = [Double](repeating: 0, count: u.count)
        for k in 1..<(u.count - 1) { slope[k] = (u[k + 1] - u[k - 1]) / 2 }
        func clamp(_ k: Int) -> Int { min(max(k, 1), u.count - 2) }

        let qrsLo = clamp(r0 - s(0.12)), qrsHi = clamp(r0 + s(0.12))
        let slopeMax = (qrsLo...qrsHi).map { abs(slope[$0]) }.max() ?? 0
        guard slopeMax > 0, u[r0] > 0 else { return nil }
        let flat = 0.1 * slopeMax

        var qrsOn: Int?
        for k in stride(from: r0, through: clamp(r0 - s(0.15)) + 1, by: -1)
            where abs(slope[k]) < flat && abs(slope[k - 1]) < flat { qrsOn = k; break }
        let minimum = (r0...clamp(r0 + s(0.08))).min { u[$0] < u[$1] } ?? r0
        // A monophasic QRS has no S trough. Searching from its window minimum otherwise starts at
        // +80 ms, after the actual end of the descending R flank.
        let sTrough = u[minimum] < -0.08 * u[r0] ? minimum : r0
        var jPoint: Int?
        for k in sTrough..<clamp(r0 + s(0.18)) where abs(slope[k]) < flat
            && abs(slope[k + 1]) < flat && abs(u[k]) < 0.15 * u[r0] {
            jPoint = k; break
        }
        guard let qrsOn, let jPoint else { return nil }

        // T wave: the largest deflection after the J point, ending before the next beat could start.
        let rAmplitude = u[r0]
        var tPeak: Int?, tEnd: Double?
        let tLo = clamp(jPoint + s(0.06))
        let tHi = clamp(min(r0 + s(0.45), r0 + s(0.7 * meanRRms / 1000)))
        if tLo < tHi, let peak = (tLo...tHi).max(by: { abs(u[$0]) < abs(u[$1]) }),
           abs(u[peak]) > 0.05 * rAmplitude {
            tPeak = peak
            let sign: Double = u[peak] > 0 ? 1 : -1
            // The next beat's QRS starts one RR after this one's; neither search may reach it.
            let nextOnset = qrsOn + s(meanRRms / 1000)
            let descentHi = clamp(min(peak + s(0.2), nextOnset - s(0.02)))
            // T end by the trapezium-area method (Vázquez-Seisdedos et al., 2011, BioMed Eng OnLine 10:43):
            // from the steepest point of the descending limb x_m, each candidate x_i spans a trapezium with
            // the fixed point x_r after the wave; the T end is the x_i of largest area
            // A_i = 0.5 * (y_m - y_i) * (2 x_r - x_i - x_m). It does not depend on where the baseline sits,
            // unlike the tangent method, which crosses the zero line and ends the wave early.
            if peak < descentHi, let steepest = (peak...descentHi).min(by: { sign * slope[$0] < sign * slope[$1] }),
               sign * slope[steepest] < 0 {
                let xr = clamp(min(steepest + s(0.20), nextOnset - s(0.01)))
                if steepest < xr {
                    let ym = sign * u[steepest]
                    let best = (steepest...xr).max { a, b in
                        let areaA = 0.5 * (ym - sign * u[a]) * Double(2 * xr - a - steepest)
                        let areaB = 0.5 * (ym - sign * u[b]) * Double(2 * xr - b - steepest)
                        return areaA < areaB
                    }
                    if let best, best > steepest, best < xr { tEnd = Double(best) }
                }
            }
        }

        // P wave: a positive bump before the QRS, measured only when it stands out.
        var pPeak: Int?, pOnset: Double?
        let pLo = clamp(r0 - s(min(0.30, 0.45 * meanRRms / 1000))), pHi = clamp(qrsOn - s(0.04))
        if pLo < pHi, let peak = (pLo...pHi).max(by: { u[$0] < u[$1] }), u[peak] > 0.03 * rAmplitude,
           peak > pLo {
            pPeak = peak
            let riseLo = clamp(peak - s(0.12))
            if riseLo < peak, let steepest = (riseLo..<peak).max(by: { slope[$0] < slope[$1] }), slope[steepest] > 0 {
                let crossing = Double(steepest) - u[steepest] / slope[steepest]
                if crossing < Double(peak), crossing >= Double(pLo) { pOnset = crossing }
            }
        }

        return Fiducials(pOnsetMs: pOnset.map(ms), pPeakMs: pPeak.map { ms(Double($0)) },
                         qrsOnsetMs: ms(Double(qrsOn)), jPointMs: ms(Double(jPoint)),
                         tPeakMs: tPeak.map { ms(Double($0)) }, tEndMs: tEnd.map(ms))
    }

    // MARK: - Helpers

    /// Vertex of a three-sample parabola around a local maximum, bounded to half a sample.
    /// Flat, non-finite or non-maximum triplets retain their original sample position.
    static func peakOffset(left: Double, center: Double, right: Double) -> Double {
        guard left.isFinite, center.isFinite, right.isFinite,
              center >= left, center >= right else { return 0 }
        let curvature = left - 2 * center + right
        guard curvature.isFinite, curvature < 0 else { return 0 }
        let offset = 0.5 * (left - right) / curvature
        guard offset.isFinite else { return 0 }
        return min(0.5, max(-0.5, offset))
    }

    /// Inverts y[n] = a (y[n-1] + x[n] - x[n-1]), a = 1 / (1 + 2 pi fc / fs), per contiguous run, keeping a
    /// 0.05 Hz high-pass in its place. A gap restarts the run; the runs are never bridged.
    static func undoHighPass(_ samples: [Int16?], cutoffHz: Double, sampleRate fs: Double) -> [Int16?] {
        let a = 1 / (1 + 2 * Double.pi * cutoffHz / fs)
        let keep = 1 / (1 + 2 * Double.pi * 0.05 / fs)
        var out = [Int16?](repeating: nil, count: samples.count)
        var previousIn: Double?
        var previousOut = 0.0
        for k in samples.indices {
            guard let raw = samples[k] else { previousIn = nil; continue }
            let y = Double(raw)
            let x = previousIn.map { keep * previousOut + y / a - $0 } ?? 0
            previousIn = y
            previousOut = x
            out[k] = Int16(clamping: Int(x.rounded()))
        }
        return out
    }

    static func medianFilter(_ x: [Double], width: Int) -> [Double] {
        let half = width / 2
        return x.indices.map { k in median(Array(x[max(0, k - half)...min(x.count - 1, k + half)])) }
    }

    static func median(_ values: [Double]) -> Double {
        guard !values.isEmpty else { return 0 }
        let sorted = values.sorted()
        let mid = sorted.count / 2
        return sorted.count % 2 == 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid]
    }

    static func percentile(_ values: [Double], _ p: Double) -> Double {
        guard !values.isEmpty else { return 0 }
        let sorted = values.sorted()
        return sorted[min(sorted.count - 1, Int(Double(sorted.count - 1) * p))]
    }

    static func standardDeviation(_ values: [Double]) -> Double {
        let mean = values.reduce(0, +) / Double(values.count)
        return (values.map { ($0 - mean) * ($0 - mean) }.reduce(0, +) / Double(values.count)).squareRoot()
    }

    static func columnMedian(_ rows: [[Double]]) -> [Double] {
        (0..<(rows.first?.count ?? 0)).map { c in median(rows.map { $0[c] }) }
    }

    static func pearson(_ a: [Double], _ b: [Double]) -> Double {
        let ma = a.reduce(0, +) / Double(a.count), mb = b.reduce(0, +) / Double(b.count)
        var num = 0.0, da = 0.0, db = 0.0
        for k in a.indices {
            num += (a[k] - ma) * (b[k] - mb)
            da += (a[k] - ma) * (a[k] - ma)
            db += (b[k] - mb) * (b[k] - mb)
        }
        return da > 0 && db > 0 ? num / (da * db).squareRoot() : 0
    }

    static func within(_ value: Double, _ range: ClosedRange<Double>) -> Double? {
        range.contains(value) ? value : nil
    }
}

/// The P-wave part of the wavelet ECG delineator of Martinez, Almeida, Olmos, Rocha and Laguna, "A
/// wavelet-based ECG delineator: evaluation on standard databases", IEEE Trans. Biomed. Eng. 51(4), 2004,
/// applied to a median beat. The beat is brought from 100 Hz to the paper's 250 Hz by linear interpolation,
/// then transformed with the paper's quadratic-spline wavelet a trous (prototype filters h = [1 3 3 1] / 8,
/// g = 2 [1 -1], dilated by 2^(k-1) at scale 2^k). The thresholds are the paper's: QRS onset where |W_2^2|
/// falls under 0.05 (0.07 for a negative maximum) of the first significant modulus maximum; P maxima
/// significant above 0.02 RMS of W_2^4 in the search window (A.4); P onset where |W_2^4| falls under 0.5 of
/// the first P maximum, or at a local minimum of |W| first.
enum WaveletDelineator {
    static let fs = 250.0

    /// P onset and QRS onset in ms relative to R, or nil when either is not found.
    static func pWave(_ template100: [Double], rIndex: Int, meanRRms: Double) -> (pOnsetMs: Double, qrsOnsetMs: Double)? {
        guard template100.count > 2 else { return nil }
        var x: [Double] = []
        var k = 0
        while Double(k) * 0.4 <= Double(template100.count - 1) + 1e-9 {
            let t = Double(k) * 0.4
            let i = min(Int(t), template100.count - 2)
            x.append(template100[i] + (template100[i + 1] - template100[i]) * (t - Double(i)))
            k += 1
        }
        let pad = 128
        x = Array(repeating: x[0], count: pad) + x + Array(repeating: x[x.count - 1], count: pad)
        let r = Int((Double(rIndex) * 2.5).rounded(.toNearestOrEven)) + pad
        let w = transform(x, levels: 4)
        guard let w2 = w[2], let w4 = w[4] else { return nil }
        func S(_ seconds: Double) -> Int { Int((seconds * fs).rounded(.toNearestOrEven)) }
        func ms(_ i: Int) -> Double { Double(i - r) * 1000 / fs }

        let near = modulusMaxima(w2, r - S(0.12), r + S(0.12))
        guard let peak = near.map({ abs(w2[$0]) }).max() else { return nil }
        let significant = near.filter { abs(w2[$0]) > 0.1 * peak }
        guard significant.count >= 2 else { return nil }
        let first = significant[0]
        let xiOn = (w2[first] > 0 ? 0.05 : 0.07) * abs(w2[first])
        guard let qon = walk(w2, from: first, step: -1, below: xiOn, stop: r - S(0.2)) else { return nil }

        let rr = meanRRms / 1000
        let lo = qon - S(min(0.30, 0.45 * rr)), hi = qon - S(0.02)
        guard lo >= 0, hi > lo else { return nil }
        let energy = (lo..<hi).map { w4[$0] * w4[$0] }.reduce(0, +) / Double(hi - lo)
        let eps = 0.02 * energy.squareRoot()
        let candidates = modulusMaxima(w4, lo, hi).filter { abs(w4[$0]) > eps }
        guard candidates.count >= 2 else { return nil }
        // The two largest maxima bound the P wave; the earlier one carries its onset. Ties keep index order,
        // as a stable sort does.
        let ranked = candidates.enumerated().sorted { a, b in
            let ha = abs(w4[a.element]), hb = abs(w4[b.element])
            return ha != hb ? ha > hb : a.offset < b.offset
        }
        let largest = ranked.prefix(2).map { $0.element }.sorted()
        let na = largest[0]
        guard let pon = walk(w4, from: na, step: -1, below: 0.5 * abs(w4[na]), stop: lo - S(0.1)) else { return nil }
        return (ms(pon), ms(qon))
    }

    /// W_2^k for k = 1 ... levels, signed so W > 0 on a rising slope, each the same length as `x` and
    /// centred on the equivalent filter's midpoint (the filters are symmetric, so there is no residual delay).
    static func transform(_ x: [Double], levels: Int) -> [Int: [Double]] {
        let h = [1.0, 3, 3, 1].map { $0 / 8 }, g = [2.0, -2]
        var result: [Int: [Double]] = [:]
        var approx = [1.0]
        for k in 1...levels {
            let gk = convolve(approx, dilate(g, k)), hk = convolve(approx, dilate(h, k))
            result[k] = convolveSame(x, gk).map { -$0 }
            approx = hk
        }
        return result
    }

    static func dilate(_ f: [Double], _ k: Int) -> [Double] {
        guard k > 1 else { return f }
        let step = 1 << (k - 1)
        var out = [Double](repeating: 0, count: (f.count - 1) * step + 1)
        for (i, v) in f.enumerated() { out[i * step] = v }
        return out
    }

    static func convolve(_ a: [Double], _ b: [Double]) -> [Double] {
        var out = [Double](repeating: 0, count: a.count + b.count - 1)
        for i in a.indices { for j in b.indices { out[i + j] += a[i] * b[j] } }
        return out
    }

    /// numpy's convolve(x, k, mode="same"): the full convolution's central len(x) values.
    static func convolveSame(_ x: [Double], _ k: [Double]) -> [Double] {
        let offset = (k.count - 1) / 2
        return x.indices.map { i in
            let n = i + offset
            var sum = 0.0
            for j in k.indices { let m = n - j; if m >= 0 && m < x.count { sum += x[m] * k[j] } }
            return sum
        }
    }

    static func modulusMaxima(_ w: [Double], _ lo: Int, _ hi: Int) -> [Int] {
        let a = max(lo, 1), b = min(hi, w.count - 2)
        guard a <= b else { return [] }
        return (a...b).filter { abs(w[$0]) >= abs(w[$0 - 1]) && abs(w[$0]) > abs(w[$0 + 1]) }
    }

    /// From `start`, step until |W| falls under `below` or reaches a local minimum, never passing `stop`.
    static func walk(_ w: [Double], from start: Int, step: Int, below: Double, stop: Int) -> Int? {
        var i = start
        while i > 0, i < w.count - 1, (i - stop) * step < 0 {
            if abs(w[i]) < below { return i }
            if abs(w[i + step]) > abs(w[i]) { return i }
            i += step
        }
        return nil
    }
}

/// Brings a strip recorded at another rate onto the 100 Hz grid `EcgAnalysis` measures on, so a
/// reference recording (an Apple Watch ECG at about 512 Hz) is measured by exactly the same code as the
/// strap's. A moving average one output period wide stops content above 50 Hz folding back into the
/// band, then each 10 ms point is read off by linear interpolation.
public enum EcgResample {
    public static func toHundredHertz(_ samples: [Double], rate: Double) -> [Int16?] {
        guard rate > 0, samples.count > 1 else { return [] }
        let width = max(1, Int((rate / 100).rounded()))
        var smoothed = samples
        if width > 1 {
            var prefix = [0.0]
            prefix.reserveCapacity(samples.count + 1)
            for value in samples { prefix.append(prefix[prefix.count - 1] + value) }
            let half = width / 2
            for k in samples.indices {
                let lo = max(0, k - half), hi = min(samples.count, k - half + width)
                smoothed[k] = (prefix[hi] - prefix[lo]) / Double(hi - lo)
            }
        }
        let count = Int(Double(samples.count - 1) / rate * 100) + 1
        return (0..<count).map { k -> Int16? in
            let position = Double(k) / 100 * rate
            let i = min(Int(position), smoothed.count - 2)
            let fraction = position - Double(i)
            let value = smoothed[i] + (smoothed[i + 1] - smoothed[i]) * fraction
            return Int16(clamping: Int(value.rounded()))
        }
    }
}
